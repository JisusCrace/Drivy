package com.jfh.patronbridge

// Interfaz implementadora
interface InterfazMetodoPago {
    fun completarPago(): String
}

// Implementaciones concretas
class Paypal : InterfazMetodoPago {
    override fun completarPago(): String {
        return "🔐 Transacción segura realizada con PayPal. ¡Gracias por su confianza!"
    }
}

class MercadoPago : InterfazMetodoPago {
    override fun completarPago(): String {
        return "💳 Pago exitoso a través de MercadoPago. ¡Nos vemos en tu parada!"
    }
}

// Interfaz de la abstracción
interface InterfazPago {
    fun realizarPago(): String
}

// Implementación concreta que actúa como puente
class Pago(private val metodo: InterfazMetodoPago) : InterfazPago {
    override fun realizarPago(): String {
        return metodo.completarPago()
    }
}

// Clase que simula la lógica del sistema de reservas
class GestorReserva {
    fun dispatch(pago: InterfazPago): String {
        val resultado = pago.realizarPago()
        return "🚌 Reserva confirmada.\n$resultado"
    }
}

// Función principal para correr en terminal
fun main() {
    val gestor = GestorReserva()

    println("=== Selección de Método de Pago ===")
    println("1. PayPal")
    println("2. MercadoPago")
    print("Ingresa el número de tu elección: ")

    when (readlnOrNull()) {
        "1" -> {
            val pago = Pago(Paypal())
            println(gestor.dispatch(pago))
        }
        "2" -> {
            val pago = Pago(MercadoPago())
            println(gestor.dispatch(pago))
        }
        else -> println("❌ Opción no válida. Intenta de nuevo.")
    }
}
