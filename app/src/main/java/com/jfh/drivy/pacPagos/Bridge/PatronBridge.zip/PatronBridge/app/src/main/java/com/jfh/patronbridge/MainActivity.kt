// -------- INTERFAZ: Método de Pago --------
interface InterfazMetodoPago {
    fun completarPago(): String
}

// -------- IMPLEMENTACIONES CONCRETAS DEL MÉTODO DE PAGO --------
class Paypal : InterfazMetodoPago {
    override fun completarPago(): String {
        return "Pago procesado con PayPal."
    }
}

class MercadoPago : InterfazMetodoPago {
    override fun completarPago(): String {
        return "Pago procesado con MercadoPago."
    }
}

// -------- INTERFAZ: Pago (Abstracción) --------
interface InterfazPago {
    fun realizarPago(): String
}

// -------- CLASE CONCRETA: Pago (Abstracción refinada) --------
class Pago(private val metodo: InterfazMetodoPago) : InterfazPago {
    override fun realizarPago(): String {
        return metodo.completarPago()
    }
}

// -------- GESTOR DE RESERVAS QUE USA LA INTERFAZ DE PAGO --------
class GestorReserva {
    fun dispatch(pago: InterfazPago): String {
        return "Reserva creada. ${pago.realizarPago()}"
    }
}

// -------- FUNCIÓN PRINCIPAL PARA PROBAR --------
fun main() {
    val gestor = GestorReserva()

    // Selección de método PayPal
    val pagoConPaypal = Pago(Paypal())
    println(gestor.dispatch(pagoConPaypal))

    // Selección de método MercadoPago
    val pagoConMercadoPago = Pago(MercadoPago())
    println(gestor.dispatch(pagoConMercadoPago))
}
