package PAC_Reserva

class CodigoVerificacion
{
    val codigo: String = (100000..999999).random().toString()
}
