package PAC_Reserva

class DatosConductor
{
    var nombre: String = ""
    var licencia: String = ""

    fun capturarDatos()
    {
        print("Nombre del conductor: ")
        nombre = readln()
        print("Licencia del conductor: ")
        licencia = readln()
    }
}
