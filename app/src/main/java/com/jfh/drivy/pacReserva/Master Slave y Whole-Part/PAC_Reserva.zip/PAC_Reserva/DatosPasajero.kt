package PAC_Reserva

class DatosPasajero
{
    var nombre: String = ""
    var correo: String = ""

    fun capturarDatos()
    {
        print("Nombre del pasajero: ")
        nombre = readln()
        print("Correo del pasajero: ")
        correo = readln()
    }
}
