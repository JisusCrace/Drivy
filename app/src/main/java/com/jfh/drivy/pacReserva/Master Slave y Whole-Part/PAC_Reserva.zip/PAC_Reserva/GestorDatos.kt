package PAC_Reserva

class GestorDatos
{
    fun obtenerDatosPasajero(): DatosPasajero
    {
        val datos = DatosPasajero()
        datos.capturarDatos()
        println("Datos del pasajero obtenidos por gestor de datos.")
        return datos
    }

    fun obtenerDatosConductor(): DatosConductor
    {
        val datos = DatosConductor()
        datos.capturarDatos()
        println("Datos del conductor obtenidos por gestor de datos.")
        return datos
    }

    fun generarCodigoVerificacion(): CodigoVerificacion
    {
        println("Código de verificación obtenido por gestor de datos.")
        return CodigoVerificacion()
    }
}
