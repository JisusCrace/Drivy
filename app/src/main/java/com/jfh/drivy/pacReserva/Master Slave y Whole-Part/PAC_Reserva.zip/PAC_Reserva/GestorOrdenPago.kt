package PAC_Reserva

class GestorOrdenPago
{
    fun generarOrdenPago(): OrdenPago
    {
        val orden = OrdenPago()
        orden.capturarDatos()
        return orden
    }
}
