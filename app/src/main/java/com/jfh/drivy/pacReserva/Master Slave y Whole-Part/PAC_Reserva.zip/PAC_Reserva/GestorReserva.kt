package PAC_Reserva

class GestorReserva
{
    private val gestorDatos = GestorDatos()
    private val gestorRuta = GestorRuta()
    private val gestorOrdenPago = GestorOrdenPago()

    fun crearReserva(): Reserva
    {
        println("\nEsclavo gestor de datos empieza a trabajar.")
        val datosPasajero = gestorDatos.obtenerDatosPasajero()
        val datosConductor = gestorDatos.obtenerDatosConductor()
        val codigoVerificacion = gestorDatos.generarCodigoVerificacion()
        println("Esclavo gestor de datos termina de trabajar.")
        println("\nEsclavo gestor de orden de pago empieza a trabajar.")
        val ordenPago = gestorOrdenPago.generarOrdenPago()
        println("Esclavo gestor de orden de pago termina de trabajar.")
        println("\nEsclavo gestor de ruta empieza a trabajar.")
        val ruta = gestorRuta.generarRuta()
        println("Esclavo gestor de ruta termina de trabajar.")

        return Reserva(datosPasajero, datosConductor, codigoVerificacion, ordenPago, ruta)
    }
}
