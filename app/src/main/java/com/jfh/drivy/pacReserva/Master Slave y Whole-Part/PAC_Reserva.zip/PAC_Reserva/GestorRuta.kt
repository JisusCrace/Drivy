package PAC_Reserva

class GestorRuta
{
    fun generarRuta(): Ruta
    {
        val ruta = Ruta()
        ruta.capturarDatos()
        return ruta
    }
}
