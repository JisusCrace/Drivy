package PAC_Reserva

fun main()
{
    val gestorReserva = GestorReserva()
    val reserva = gestorReserva.crearReserva()

    println("\nDetalles de la reserva:")
    println("El nombre del pasajero es ${reserva.datosPasajero.nombre} y su correo es ${reserva.datosPasajero.correo}.")
    println("El nombre del conductor es ${reserva.datosConductor.nombre} y su licencia es ${reserva.datosConductor.licencia}.")
    println("La ruta es de ${reserva.ruta.origen} a ${reserva.ruta.destino} con una distancia de ${reserva.ruta.distancia} km.")
    println("La cantidad total que se pagará por el viaje es de $${reserva.ordenPago.monto} MXN.")
    println("El código de verificación es ${reserva.codigoVerificacion.codigo}.")

    println("Reserva realizada.")
}
