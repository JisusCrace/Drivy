package PAC_Reserva

class OrdenPago
{
    var monto: Double = 0.0

    fun capturarDatos()
    {
        print("Monto a pagar: ")
        monto = readln().toDouble()
    }
}
