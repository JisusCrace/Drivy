package PAC_Reserva

class Reserva(
    val datosPasajero: DatosPasajero,
    val datosConductor: DatosConductor,
    val codigoVerificacion: CodigoVerificacion,
    val ordenPago: OrdenPago,
    val ruta: Ruta
)
