package PAC_Reserva

class Ruta
{
    var origen: String = ""
    var destino: String = ""
    var distancia: Double = 0.0

    fun capturarDatos()
    {
        print("Origen del viaje: ")
        origen = readln()
        print("Destino del viaje: ")
        destino = readln()
        distancia = if (origen != destino) 123.456 else 0.0
    }
}
