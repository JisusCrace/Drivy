import java.util.Base64

// --- API externa simulada (Adaptee) ---
class ApiGooglePhotos {
    fun tomarRutaFoto(): String {
        // Simula una ruta devuelta por la API
        return "path/to/foto.png"
    }
}

// --- Interfaz esperada por el sistema (Target) ---
interface GestorImagen {
    fun seleccionarFoto(): String
}

// --- Adaptador que convierte la respuesta de la API al formato requerido (Adapter) ---
class AdaptadorGooglePhotos(private val api: ApiGooglePhotos) : GestorImagen {

    override fun seleccionarFoto(): String {
        val ruta = api.tomarRutaFoto()
        println("📸 Foto seleccionada en: $ruta")

        // Simulación de conversión a base64 (normalmente se leería un archivo)
        return convertirABase64Simulada(ruta)
    }

    private fun convertirABase64Simulada(ruta: String): String {
        val textoSimulado = "Imagen desde $ruta"
        val base64 = Base64.getEncoder().encodeToString(textoSimulado.toByteArray())
        return "data:image/png;base64,$base64"
    }
}

// --- Cliente 1: Registro de usuario (Pasajero o Conductor) ---
class Registro(private val gestorImagen: GestorImagen) {
    fun subirFotoPerfil(): String {
        val imagen = gestorImagen.seleccionarFoto()
        return "✅ Perfil registrado con imagen:\n$imagen"
    }
}

// --- Cliente 2: Registro de vehículo ---
class Vehiculo(private val gestorImagen: GestorImagen) {
    fun subirFotoVehiculo(): String {
        val imagen = gestorImagen.seleccionarFoto()
        return "🚗 Vehículo registrado con imagen:\n$imagen"
    }
}

// --- Punto de entrada del programa ---
fun main() {
    val api = ApiGooglePhotos()
    val adaptador = AdaptadorGooglePhotos(api)

    println("=== Sistema de Registro ===")
    println("1. Registrar cuenta (Pasajero/Conductor)")
    println("2. Registrar vehículo")
    print("Selecciona una opción (1 o 2): ")

    when (readlnOrNull()) {
        "1" -> {
            val registro = Registro(adaptador)
            println(registro.subirFotoPerfil())
        }
        "2" -> {
            val vehiculo = Vehiculo(adaptador)
            println(vehiculo.subirFotoVehiculo())
        }
        else -> println("❌ Opción no válida.")
    }
}
