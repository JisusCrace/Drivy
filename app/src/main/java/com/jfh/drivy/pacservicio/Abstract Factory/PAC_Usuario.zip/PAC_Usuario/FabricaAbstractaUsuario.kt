package PAC_Usuario

interface FabricaAbstractaUsuario
{
    fun crearFormularioRegistro(): FormularioRegistro
    fun crearFormularioAutentificacion(): FormularioAutentificacion
}
