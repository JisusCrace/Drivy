package PAC_Usuario

class FabricaConcretaConductor : FabricaAbstractaUsuario
{
    override fun crearFormularioRegistro(): FormularioRegistro = FormularioRegistroConductor()
    override fun crearFormularioAutentificacion(): FormularioAutentificacion = FormularioAutentificacionConductor()
}
