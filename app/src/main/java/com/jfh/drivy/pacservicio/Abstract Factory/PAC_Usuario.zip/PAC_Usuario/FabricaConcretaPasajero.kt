package PAC_Usuario

class FabricaConcretaPasajero : FabricaAbstractaUsuario
{
    override fun crearFormularioRegistro(): FormularioRegistro = FormularioRegistroPasajero()
    override fun crearFormularioAutentificacion(): FormularioAutentificacion = FormularioAutentificacionPasajero()
}
