package PAC_Usuario

interface FormularioAutentificacion
{
    fun mostrarFormulario()
    fun autentificar(datos: Map<String, String>)
}
