package PAC_Usuario

class FormularioAutentificacionConductor : FormularioAutentificacion
{
    private var matricula: String = ""
    private var contrasena: String = ""
    private var licencia: String = ""

    override fun mostrarFormulario() {
        println("╔═══════════════════════════════════════╗")
        println("║FORMULARIO DE AUTENTIFICACION CONDUCTOR║")
        println("╠═══════════════════════════════════════╣")
        println("║ Matrícula:      _____________________ ║")
        println("║ Contraseña:     _____________________ ║")
        println("║ Licencia:       _____________________ ║")
        println("╚═══════════════════════════════════════╝")
    }

    override fun autentificar(datos: Map<String, String>)
    {
        val matricula = datos["matricula"] ?: ""
        val contrasena = datos["contrasena"] ?: ""
        val licencia = datos["licencia"] ?: ""
        println("Autentificando conductor con matrícula $matricula, contraseña $contrasena y licencia $licencia.")
    }
}
