package PAC_Usuario

class FormularioAutentificacionPasajero : FormularioAutentificacion
{
    private var matricula: String = ""
    private var contrasena: String = ""

    override fun mostrarFormulario()
    {
        println("╔══════════════════════════════════════╗")
        println("║FORMULARIO DE AUTENTIFICACION PASAJERO║")
        println("╠══════════════════════════════════════╣")
        println("║ Matrícula:      ____________________ ║")
        println("║ Contraseña:     ____________________ ║")
        println("╚══════════════════════════════════════╝")
    }

    override fun autentificar(datos: Map<String, String>)
    {
        val matricula = datos["matricula"] ?: ""
        val contrasena = datos["contrasena"] ?: ""
        println("Autentificando pasajero con matricula $matricula y contraseña $contrasena.")
    }
}
