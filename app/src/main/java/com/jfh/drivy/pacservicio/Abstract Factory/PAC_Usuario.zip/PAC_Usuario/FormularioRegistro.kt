package PAC_Usuario

interface FormularioRegistro
{
    fun mostrarFormulario()
    fun setDatos(datos: Map<String, String>)
    fun getDatos(): Map<String, String>
}
