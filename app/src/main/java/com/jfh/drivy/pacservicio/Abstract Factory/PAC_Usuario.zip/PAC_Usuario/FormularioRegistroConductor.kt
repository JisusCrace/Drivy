package PAC_Usuario

class FormularioRegistroConductor : FormularioRegistro
{
    private var matricula: String = ""
    private var nombre: String = ""
    private var correo: String = ""
    private var contrasena: String = ""
    private var licencia: String = ""

    override fun mostrarFormulario() {
        println("╔═══════════════════════════════════════╗")
        println("║    FORMULARIO DE REGISTRO CONDUCTOR   ║")
        println("╠═══════════════════════════════════════╣")
        println("║ Matrícula:      _____________________ ║")
        println("║ Nombre:         _____________________ ║")
        println("║ Correo:         _____________________ ║")
        println("║ Contraseña:     _____________________ ║")
        println("║ Licencia:       _____________________ ║")
        println("╚═══════════════════════════════════════╝")
    }

    override fun setDatos(datos: Map<String, String>)
    {
        matricula = datos["matricula"] ?: ""
        nombre = datos["nombre"] ?: ""
        correo = datos["correo"] ?: ""
        contrasena = datos["contrasena"] ?: ""
        licencia = datos["licencia"] ?: ""
    }

    override fun getDatos(): Map<String, String> {
        return mapOf(
            "matricula" to matricula,
            "nombre" to nombre,
            "correo" to correo,
            "licencia" to licencia
        )
    }
}
