package PAC_Usuario

fun procesarRegistro(formulario: FormularioRegistro, datos: Map<String, String>)
{
    formulario.setDatos(datos)
    println("Datos recibidos para el registro:")
    formulario.getDatos().forEach { (clave, valor) ->
        println("   $clave: $valor")
    }
    println("Registro completado con éxito.")
}

fun procesarAutentificacion(autentificador: FormularioAutentificacion, datos: Map<String, String>)
{
    autentificador.autentificar(datos)
    println("✅ Inicio de sesión completado.")
}

