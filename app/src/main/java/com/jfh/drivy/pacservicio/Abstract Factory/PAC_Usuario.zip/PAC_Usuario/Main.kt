package PAC_Usuario

fun main()
{
    println("Seleccione una opción:")
    println("1.- Registrarse como pasajero")
    println("2.- Registrarse como conductor")
    println("3.- Iniciar sesión como pasajero")
    println("4.- Iniciar sesión como conductor")

    when(readln())
    {
        "1" -> {
            val factory = FabricaConcretaPasajero()
            val formulario = factory.crearFormularioRegistro()
            formulario.mostrarFormulario()
            val datos = solicitarDatosRegistroPasajero()
            procesarRegistro(formulario, datos)
        }
        "2" -> {
            val factory = FabricaConcretaConductor()
            val formulario = factory.crearFormularioRegistro()
            formulario.mostrarFormulario()
            val datos = solicitarDatosRegistroConductor()
            procesarRegistro(formulario, datos)
        }
        "3" -> {
            val factory = FabricaConcretaPasajero()
            val autentificador = factory.crearFormularioAutentificacion()
            autentificador.mostrarFormulario()
            val datos = solicitarDatosAutentificacionPasajero()
            procesarAutentificacion(autentificador, datos)
        }
        "4" -> {
            val factory = FabricaConcretaConductor()
            val autentificador = factory.crearFormularioAutentificacion()
            autentificador.mostrarFormulario()
            val datos = solicitarDatosAutentificacionConductor()
            procesarAutentificacion(autentificador, datos)
        }
        else -> println("Opción seleccionada inválida")
    }
}

fun solicitarDatosRegistroPasajero(): Map<String, String> {
    print("Matrícula: ")
    val matricula = readln()
    print("Nombre completo: ")
    val nombre = readln()
    print("Correo electrónico: ")
    val correo = readln()
    print("Contraseña: ")
    val contrasena = readln()

    return mapOf(
        "matricula" to matricula,
        "nombre" to nombre,
        "correo" to correo,
        "contrasena" to contrasena
    )
}

fun solicitarDatosRegistroConductor(): Map<String, String> {
    print("Matrícula: ")
    val matricula = readln()
    print("Nombre completo: ")
    val nombre = readln()
    print("Correo electrónico: ")
    val correo = readln()
    print("Contraseña: ")
    val contrasena = readln()
    print("Número de licencia: ")
    val licencia = readln()

    return mapOf(
        "matricula" to matricula,
        "nombre" to nombre,
        "correo" to correo,
        "contrasena" to contrasena,
        "licencia" to licencia
    )
}

fun solicitarDatosAutentificacionPasajero(): Map<String, String> {
    print("Introduce matrícula del pasajero: ")
    val matricula = readln()
    print("Introduce contraseña: ")
    val contrasena = readln()

    return mapOf(
        "matricula" to matricula,
        "contrasena" to contrasena
    )
}

fun solicitarDatosAutentificacionConductor(): Map<String, String>
{
    print("Introduce matrícula del conductor: ")
    val matricula = readln()
    print("Introduce contraseña: ")
    val contrasena = readln()
    print("Introduce número de licencia: ")
    val licencia = readln()

    return mapOf(
        "matricula" to matricula,
        "contrasena" to contrasena,
        "licencia" to licencia
    )
}
